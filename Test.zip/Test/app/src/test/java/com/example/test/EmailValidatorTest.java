package com.example.test;

import static org.junit.Assert.assertTrue; // Melakukan impor metode assertTrue dari library JUnit
import org.junit.Test; // Melakukan impor anotasi (Test) dari library JUnit

public class EmailValidatorTest {
    @Test // Anotasi @Test untuk menandai metode sebagai metode test JUnit
    public void emailValidator_CorrectEmailSimple_ReturnsTrue() {
        // Menentukan email yang tepat
        String validEmail = "anisa@gmail.com";

        // Memanggil metode assertTrue untuk mengkonfirmasi bahwa hasilnya benar
        assertTrue(EmailValidator.isTrue(validEmail));
    }
}
