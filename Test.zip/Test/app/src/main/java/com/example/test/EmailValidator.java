package com.example.test;

public class EmailValidator {
    // Pendeklrasian metode statis 'isTrue' untuk memvalidasi format email apakah telah sesusai
    public static boolean isTrue(String email) {
        // Definisi pola teks untuk memverifikasi format email
       String formatEmail = "^[A-Za-z0-9+_.-]+@(.+)$";
        // Memeriksa apakah 'email' cocok dengan pola teks yang telah ditentukan
        // Jika cocok, maka email dianggap sudah benar dan metode akan mengembalikan 'true'
        // Jika tidak cocok, maka metode akan mengembalikan 'false'

        return email.matches(formatEmail);
    }
}
